#include <iostream>
using namespace std;

/*Program to find maximum of two numbers*/

int main()
{
  float a=0,b=0;
  cout<<"Program to find maximum of two numbers";
  cout<<"\n \nEnter two different numbers: ";
  cin>>a>>b;
  cout<<"\nThe greater number is: "<<((a>b)?a:b);
  return 0;
}
